lista1 = [1,2,3,4,]
lista2 = [7,7,8,8,9,]
lista3 = [14,14,15,16]
todas_lista = [lista1,lista2,lista3]
print(todas_lista)