produtos = ['tv','celular','casa','Iphone']
novos_p = ['carro', 'bola']


produtos.sort()
print(produtos)