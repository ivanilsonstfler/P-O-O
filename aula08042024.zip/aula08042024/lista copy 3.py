produtos = ['tv','celular','casa','iphone']
novos_p = ['carro', 'bola']


print(produtos)