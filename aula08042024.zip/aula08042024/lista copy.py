produtos = ['tv','celular','casa','iphone']
aux = produtos.pop(3)

print(produtos)
