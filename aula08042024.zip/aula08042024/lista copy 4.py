v = 1000
v2 = 2000
print(v)
print(v2)