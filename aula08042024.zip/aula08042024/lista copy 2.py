vendas = [10,20,30,40,50,80,90,]


print(len(vendas))
print(max(vendas))